The direct X version required for the connect 4 video game is 9.0c: http://www.microsoft.com/en-us/download/details.aspx?id=35

If the video for the inrtoduction does not play you can access the video at: http://youtu.be/0GVUjczLN1Y